# Release History

## 1.0.0-beta.1 (2020-09-08)
- Added SchemaRegistryClient with 3 operations:
  - RegisterSchema
  - GetSchemaId
  - GetSchema
