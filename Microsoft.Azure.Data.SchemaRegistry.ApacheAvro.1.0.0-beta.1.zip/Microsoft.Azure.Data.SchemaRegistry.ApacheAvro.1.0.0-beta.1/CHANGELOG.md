# Release History

## 1.0.0-beta.1 (2020-09-08)
- Added SchemaRegistryAvroObjectSerializer
  - Derives from ObjectSerializer
  - Works with 2 Avro types:
    - SpecificRecord
    - GenericRecord